#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.

# packages! -------
library(shiny)
library(tidyverse)
library(sf)
library(readxl)
library(viridis)

# load data -----
title_dat <- read_csv("data/CommAreas.csv")
# map data from Chicago Data Portal 
communities <- read_sf('data/communities/geo_export_45d4da8d-3fc8-4ccb-9b0c-8f546d526c9a.shp')

bike_routes <- read_sf('data/bikes/geo_export_02f6b9aa-6d14-4951-9963-31aeaa95c2b8.shp')

# changing communities ID variable so it can be joined with crimes
communities <- communities %>% 
  mutate(area_numbe = as.numeric(area_numbe))

# census data for crimes
census <- read_excel('data/neighborhood_info.xlsx')
# adjusting census data so it can be joined
census <- census %>% 
  mutate(neighborhood = tolower(neighborhood)) %>% 
  rename(community = neighborhood)

# ----------------------------

crash_dat <- read_csv("data/2021_crash_communities.csv") %>% 
  mutate(
    community = str_to_title(community),
    community = ifelse(community == "Ohare", "O'Hare", community),
    community = ifelse(community == "Mckinley Park", "McKinley Park", community),
    `Community Area Number` = NA
  ) %>% 
  rename("Crash Count" = "n") %>% 
  rename("Community" = "community") %>% 
  filter(!is.na(Community))

# crimes data - relevant
relevant_crimes <- read_csv("data/crimes_2013-2021/relevant_crimes.csv")

relevant_crimes_i <- relevant_crimes %>% 
  mutate(community = NA) %>% 
  group_by(community_area, community, year) %>% 
  select(-location_description) %>% 
  count() %>% 
  filter(!is.na(community_area))

# add community names
for (i in 1:693) {
  for (j in 1:77) {
    if (relevant_crimes_i$community_area[i] == title_dat$number[j]) {
      relevant_crimes_i$community[i] = title_dat$name[j]
    }
  }
}

# summing total crime statistics yearly
all_chicago <- relevant_crimes %>% 
  mutate(community = "All - Chicago") %>% 
  group_by(year, community) %>% 
  count()
relevant_crimes_i <- relevant_crimes_i %>% rbind(all_chicago)

# creating labels for UI
community_labs <- relevant_crimes_i$community

# counting crimes
crimes_count <- relevant_crimes %>% 
  group_by(community_area) %>% 
  summarise(num_crimes = n()) %>% 
  left_join(communities, by = c('community_area' = 'area_numbe'))

# census data for crimes
crimes_count <- crimes_count %>% 
  mutate(community = tolower(community))

# finding crime rate and other statistics
crimes_census <- crimes_count %>% 
  left_join(census)
crimes_census <- crimes_census %>% 
  mutate(crime_rate = (num_crimes / pop) * 100000,
         divvy_to_pop = (num_of_divvy_stations / pop) * 100000,
         divvy_to_area = num_of_divvy_stations / area_sq_mi)

# finding the center of each community for geom_point
crimes_census <- crimes_census %>% 
  mutate(geometry_center = st_centroid(geometry))
crimes_census <- crimes_census %>% 
  mutate(lat_lon = st_coordinates(geometry_center),
         lat = lat_lon[,"X"],
         long = lat_lon[,"Y"])

#--------------------------------

# police sentiment
sentiment_dat <- read_csv("data/sentiment_eda.csv") %>% 
  mutate(comm_number = 1:77)

# Define UI for application that draws a histogram -----
ui <- fluidPage(
  
    # App title ----
    titlePanel("Crime Cases in Chicago Over Time"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(position = "right",
        sidebarPanel(
          p("The following lineplot shows the total number of outdoor/vehicle-related
            crimes for each year from 2013-2021."),
          selectInput(inputId = "community_input", 
                      label = "Select Community:",
                      choices = as.list(community_labs),
                      selected = "Rogers Park"),
          p("Crime rate is defined as the number of crimes per 100,000 people. 
          As usual, we see that there are more bike lanes in areas with low crime 
          rates. Divvy to population rate is defined (by me) as the number of Divvy
          stations per 100,000 people. Divvy to area rate is the number of Divvy stations 
          divided by the area in square miles. The Divvy to population map doesn't yield
          much correlation, but the Divvy per area reveals a lower Divvy per area rate in 
          southern neighborhoods with more crimes."),
          selectInput(inputId = "crimerate_input", 
                      label = "Select Measure:",
                      choices = as.list(c("divvy_to_area",
                                  "divvy_to_pop")),
                      selected = "divvy_to_area"),
        ),

        # Show a plot of the generated distribution
        mainPanel(
           plotOutput("crimes_timeline"),
           plotOutput("crimerate_map")
        )
    )
)

# Define server logic required to draw timeline/map -----
server <- function(input, output) {

    output$crimes_timeline <- renderPlot({
     
      # user-supplied community area
      community_crimes <- relevant_crimes_i %>% 
        filter(community == input$community_input)
    
      # building timeline plot
      community_crimes %>% 
        ggplot(aes(x = year, y = n)) +
          geom_line(color = "black", size = 1) +
          geom_point(size = 4) +
          labs(
          x = "Year",
          y = "Crimes"
          )  +
          theme_minimal() +
          scale_x_continuous(breaks = seq(2013, 2021, 1))
      
    })
    
    output$crimerate_map <- renderPlot({
      
      # user-supplied input
      pop_or_area <- case_when(
        input$crimerate_input == "divvy_to_area" ~ pull(crimes_census, divvy_to_area),
        input$crimerate_input == "divvy_to_pop" ~ pull(crimes_census, divvy_to_pop),
      )
      
      crimes_census %>% 
            ggplot() +
            geom_sf(mapping = aes(geometry = geometry, fill = pop_or_area)) +
            geom_sf(data = bike_routes) +
            geom_point(mapping = aes(x = lat, y = long, size = crime_rate), 
                       color = "red", alpha = 0.5) +
            theme_void() +
            scale_fill_viridis()
      
      # building map
      # if (map_to_make == "divtoarea_dat") {
      #   # make area plot
      #   crimes_census %>% 
      #     ggplot() +
      #     geom_sf(mapping = aes(geometry = geometry, fill = divvy_to_area)) +
      #     geom_point(mapping = aes(x = lat, y = long, size = crime_rate), color = "red", alpha = 0.5) +
      #     theme_void() +
      #     scale_fill_viridis()
      # } else if (map_to_make == "divtopop_dat") {
      #   # make pop plot
      #   crimes_census %>% 
      #     ggplot() +
      #     geom_sf(mapping = aes(geometry = geometry, fill = divvy_to_pop)) +
      #     geom_point(mapping = aes(x = lat, y = long, size = crime_rate), color = "red", alpha = 0.5) +
      #     theme_void() +
      #     scale_fill_viridis()
      # } else {
      # crimes_census %>% 
      #   ggplot() +
      #   geom_sf(mapping = aes(geometry = geometry, fill = crime_rate)) +
      #   geom_sf(data = bike_routes) +
      #   theme_void() +
      #   scale_fill_viridis()
      # }
      
      
    })
    
      
}

# Run the application ------
shinyApp(ui = ui, server = server)
